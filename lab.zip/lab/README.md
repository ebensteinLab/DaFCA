# Lab scripts
## Installation
1. Install python 3.7 or higher from official web-site
2. Clone repo
3. From terminal execute - ``pip insall pands matplotlib PyYAML``

## Execution - convert_output_file
* cd to project directory and execute:
```python3 convert_output_file --file_path <path to input file> --csv_path <path to output file> --csv_output_prefix <name of results file> --visualize'```

* if --visualize is set we will see the graphs generated.

## Execution - execute_tasks
1. Create an execution file ``yml`` format:
    * should look like:
    ```yaml
    max_paralism: max number of process running at **same time** (reasonble values are 1-4, you can try more)
    python_alias: the python command in your system (usualy python or python3)
    path_to_execution_script : path to the execution script
    is_path_is_global : if the path above is global set it to true   
    -  executuion_someNumber: 
         param1: val1
         param2: val2
         param3_list:
           - list_val1
           - list_val2
           - list_val3
    -  executuion_<number2>: ...
    -  executuion_<number3>: ...
    ```
    * example - in this example I have a script named ``hello_world.py`` this script just prints all the input args,
    here is the ``execution_file.yml``
    ```yaml
    max_paralism: 4
    python_alias: python
    path_to_execution_script : C:\Users\Michael\Desktop\hello_world.py
    is_path_is_global : true
    executions:
      -  executuion_1:
           b: Z:\Saphyr_Data\DAM_DLE_VHL_DLE\73CBVEWLPQLGFNWU\fdaf4261-301f-42a1-9261-6c85f574f4b8\MoleculeDetect\Scan1_2\73CBVEWLPQLGFNWU\8e842048-c4e8-4cb3-8974-ef8d2d33d2fb\FC2\P1\2scansDataSet\BNXFILEgreen.bnx
           m: Z:\Saphyr_Data\DAM_DLE_VHL_DLE\73CBVEWLPQLGFNWU\fdaf4261-301f-42a1-9261-6c85f574f4b8\MoleculeDetect\Scan1_2\73CBVEWLPQLGFNWU\8e842048-c4e8-4cb3-8974-ef8d2d33d2fb\FC2\P1\2scansDataSet\PROFILEFILEred.txt
           x: Z:\Saphyr_Data\DAM_DLE_VHL_DLE\73CBVEWLPQLGFNWU\fdaf4261-301f-42a1-9261-6c85f574f4b8\MoleculeDetect\Scan1_2\73CBVEWLPQLGFNWU\8e842048-c4e8-4cb3-8974-ef8d2d33d2fb\FC2\P1\2scansDataSet\XMAPFILE.xmap
           c: Z:\Saphyr_Data\DAM_DLE_VHL_DLE\73CBVEWLPQLGFNWU\fdaf4261-301f-42a1-9261-6c85f574f4b8\MoleculeDetect\Scan1_2\73CBVEWLPQLGFNWU\8e842048-c4e8-4cb3-8974-ef8d2d33d2fb\FC2\P1\2scansDataSet\rCMAPFILE.cmap
           r:
             - 15
             - 2650
             - 2740
           p: ex1
      -  executuion_2:
           b: Z:\Saphyr_Data\DAM_DLE_VHL_DLE\73CBVEWLPQLGFNWU\fdaf4261-301f-42a1-9261-6c85f574f4b8\MoleculeDetect\Scan1_2\73CBVEWLPQLGFNWU\8e842048-c4e8-4cb3-8974-ef8d2d33d2fb\FC2\P1\2scansDataSet\BNXFILEgreen.bnx
           m: Z:\Saphyr_Data\DAM_DLE_VHL_DLE\73CBVEWLPQLGFNWU\fdaf4261-301f-42a1-9261-6c85f574f4b8\MoleculeDetect\Scan1_2\73CBVEWLPQLGFNWU\8e842048-c4e8-4cb3-8974-ef8d2d33d2fb\FC2\P1\2scansDataSet\PROFILEFILEred.txt
           x: Z:\Saphyr_Data\DAM_DLE_VHL_DLE\73CBVEWLPQLGFNWU\fdaf4261-301f-42a1-9261-6c85f574f4b8\MoleculeDetect\Scan1_2\73CBVEWLPQLGFNWU\8e842048-c4e8-4cb3-8974-ef8d2d33d2fb\FC2\P1\2scansDataSet\XMAPFILE.xmap
           c: Z:\Saphyr_Data\DAM_DLE_VHL_DLE\73CBVEWLPQLGFNWU\fdaf4261-301f-42a1-9261-6c85f574f4b8\MoleculeDetect\Scan1_2\73CBVEWLPQLGFNWU\8e842048-c4e8-4cb3-8974-ef8d2d33d2fb\FC2\P1\2scansDataSet\rCMAPFILE.cmap
           r:
             - 1234
             - 2222
             - 3333
           p: ex2
    ```
2. cd to project directory and execute:
```python3 execute_tasks --execution_file <path to execution file>```
3. The outputs(regular std-out and std-error) will appear in the outputs folder.
   
   <b>Important:</b> If folder doesnt exist script will fail, please create it. 
