import pandas as pd
from parsing.FileReader import FileReader

MOL_ID = "molID"
HEADERS = ['X', 'Y', 'MOL_ID', 'LENGTH']
X_PREFIX_IDENTIFIER = "profile_bp_"
Y_PREFIX_IDENTIFIER = "profile_intensity_"


def create_row(line: str):
    if line.endswith("\n"):
        line = line[:-1]
    if line.startswith(MOL_ID):
        return line.split("\t")[:2]
    else:
        return line.split("\t")


def resolve_column_name(name: str):
    if name.startswith(X_PREFIX_IDENTIFIER):
        return 'X'
    if name.startswith(Y_PREFIX_IDENTIFIER):
        return 'Y'
    return name


def filter_lines(line):
    return not (line.startswith('#') or line.startswith('label_bp') or line.startswith('label_intensity') or line.startswith('molID'))


def get_df_from_file(path: str):
    df = pd.DataFrame()
    fr = FileReader(path, create_row, filter_lines)
    current_df = pd.DataFrame()
    for splited_line in fr:
        column_name = resolve_column_name(splited_line[0])
        temp_df = pd.DataFrame({column_name: splited_line[1:]}, columns=[column_name])
        temp_df[column_name] = pd.to_numeric(temp_df[column_name], downcast="float")
        current_df = pd.concat([current_df, temp_df], axis=1)
        if column_name == 'Y':
            df = df.append(current_df)
            current_df = pd.DataFrame()
            df.reset_index()

    # df = df.fillna(method='ffill')
    return df