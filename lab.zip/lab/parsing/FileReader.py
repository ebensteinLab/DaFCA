class FileReader:
    def __init__(self, file_path, mapper, filter_object) -> None:
        super().__init__()
        self.file_path = file_path
        self.filter_object = filter_object
        self.mapper = mapper

    def __iter__(self):
        with open(self.file_path) as file:
            for line in file:
                if self.filter_object(line):
                    yield self.mapper(line)

    def with_reduction(self, reducer, init_state):
        current_state = init_state
        for i in self:
            current_state = reducer(current_state, i)
        return current_state

    def __next__(self):
        raise ValueError("operation un supported")
