import os

import matplotlib.pyplot as plt


def export_csv(df, path, visualize, file_name='results.csv'):
    _, axes = plt.subplots(nrows=1, ncols=2)
    df[['X', 'mean']].plot(ax=axes[0], x='X', y='mean')
    df[['X', 'std']].plot(ax=axes[1], x='X', y='std')
    df.to_csv(os.path.join(path, file_name), index=False)
    if visualize:
        plt.show()


def save_image(df, path):
    fig, axes = plt.subplots(nrows=1, ncols=1)
    df[['X', 'mean']].plot(ax=axes, x='X', y='mean')
    fig.savefig('results_mean.png')
    fig, axes = plt.subplots(nrows=1, ncols=1)
    df[['X', 'std']].plot(ax=axes, x='X', y='std')
    fig.savefig(os.path.join(path, 'results_std.png'))
